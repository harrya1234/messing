function Podium.isPodium(self)
	return true
end
